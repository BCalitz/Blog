from django.shortcuts import render
from .models import *

# Create your views here.
def index(request):

    return render(request, "home/index.html", {
        "blogs" : Blog.objects.all(),
    })


def blog(request, blog_id):
    blog = Blog.objects.get(id = blog_id)
    return render(request, "home/blog.html", {
        "blog" : blog
    })

def author(request, author_id):
    author = Author.objects.get(id = author_id)
    return render(request, "home/author.html", {
        'author':author,
        'posts':author.posts.all()
    })

def authors(request):
    authors = Author.objects.all()
    return render(request, "home/authors.html", {
        'authors':authors,
    })
    


